import { Component, OnInit } from '@angular/core';
import {Chart} from 'chart.js';

@Component({
  selector: 'charter',
  templateUrl: './chart-marker.component.html',
  styleUrls: ['./chart-marker.component.css']
})
export class ChartMarkerComponent implements OnInit {
  chart = [];
  chartX = [];
  iconPath: String = "./assets/KMP/connect-graph.svg";
  /**************Legend ***/
  icons = ["./assets/KMP/connect-yes_sm.svg",
          "./assets/KMP/connect-disclosed_sm.svg",
          "./assets/KMP/connect-no_sm.svg",
          "./assets/KMP/connect-not_sm.svg"];
          
  labels = ["Connected","Unreliable","Disconnected","Disposed:no data"];
  data = [30,40,20,10];
  backgroundColor = ["#1B8642","#6EC8A0","#CF2027","#D1D3D5"];

 /* chartOptions = {
    responsive: true,
  };

  chartData = [
    { data: [30,40, 20,10], 
      label: 'Connection',
    
      backgroundColor: ["#3e95cd","#6EC8A0","#CF2027","#D1D3D5"]}
  ];

  chartLabels = ["Connected","Unreliable","Disconnected","Disposed:no data"];

  myColors = [
    {
      backgroundColor:  ["#1B8642","#6EC8A0","#CF2027","#D1D3D5"]
     
    }];

  onChartClick(event) {
    console.log(event);
  }
  */
  constructor() {}

  ngOnInit() {
    this.chart = new Chart('canvas', {
      type: 'doughnut',
      data: {
       // labels: ["Connected","Unreliable","Disconnected","Disposed:no data"],
       labels:this.labels,
        datasets: [
          { 
            //data: [30,40,20,10],
            data:this.data,
            //backgroundColor: ["#1B8642","#6EC8A0","#CF2027","#D1D3D5"]
            backgroundColor:this.backgroundColor
          }
        ]
      },
      options: {
         cutoutPercentage: 70,
        legend: {
          display: false
        }
      }
    });
   
  }

}
