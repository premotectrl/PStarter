import { Component, OnInit, Input } from '@angular/core';
import {Chart} from 'chart.js';

@Component({
  selector: 'gauge',
  templateUrl: './gauges.component.html',
  styleUrls: ['./gauges.component.css']
})
export class GaugesComponent implements OnInit {
  chart3 = [];
  chart2 = [];
  chartX = [];
  chartY = [];
  chartI = [];
  chartV = [];  
  chartF = [];  

  
  iconPath:String = "./assets/KMP/battery-26-50.svg";
  lowBatIcon: String =  "./assets/KMP/battery-0-10.svg";
  @Input() data = [20,70];
 
  //chartData = [10,70];
  chartData= [];

  constructor() {
    this.chartData = this.data;
  }

  ngOnInit() {
    this.chart3 = new Chart('canvas3', {
      type: 'doughnut',
      data: {
        labels: ["low","high"],
        datasets: [
          { 
            data:  [10,90],
            backgroundColor: ["#3cba9f","#9cbf9f"]
          }
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        legend: {
          display: false
        }
      }
    });
    //Inner chart
    this.chart2 = new Chart('canvas2', {
      type: 'pie',
      data: {
        labels: ["low","high"],
        datasets: [
          { 
            data: [10,90],
           
           // backgroundColor: ["#1fd6ef"],
            backgroundColor: ["rgba(196, 93, 105, 1)","rgba(32, 162, 219, 0)"],
            borderColor: ["#fff","#fff"],
            borderWidth: [0,2],
           
          },
          { 
            data: [10,90],
            backgroundColor: ["rgba(196, 93, 105, 0)","rgba(32, 162, 219, 0)"],
            //backgroundColor: ["#fff"],
            borderColor: ["#fff","#fe86ef"],
            borderWidth: [0,1]
          }
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        //cutoutPercentage: 60,
        //radiusPercentage: 0.5,
        tooltips: {enabled: false},
        hover: {mode: null},
        legend: {
          display: false
        },
      }
    });

     //************outer */
     this.chartX = new Chart('canvasX', {
      type: 'pie',
      data: {
        labels: ["Connected","Unreliable","Disconnected","Disposed:no data"],
        datasets: [
          { 
            data: [70,20,30],
            backgroundColor: ["#E1E2E3","#D1D3D5","#A4A7AA"],
            borderWidth: [0.5]
           
            //segmentStrokeColor: "rgba(255,255,255,0)"
          }
        ]
      },
      options: {
         //segmentStrokeWidth : [2,3,5],
         cutoutPercentage: 80,
         rotation: 1 * Math.PI,
         circumference: 1 * Math.PI,
        legend: {
          display: false
        }
      }
    });


     //************Version 2 ++++ pointer **********************/
     //backdrop chart
     this.chartV = new Chart('canvasBck', {
      type: 'pie',
      data: {
        labels: [],
        datasets: [
          { 
            data: [70,20,30],
            backgroundColor: ["#E1E2E3","#D1D3D5","#A4A7AA"],
            borderWidth: [0.5,0.5,0.5]
          }
         
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        cutoutPercentage: 80,
        legend: {
          display: false
        }
      }
    }); 
    //pointer
    this.chartI = new Chart('canvas', {
      type: 'pie',
      data: {
        labels: ["low","high"],
        datasets: [
          { 
            data: this.chartData,
            backgroundColor:["rgba(0, 0, 0, 0)", "rgba(255, 254, 230, 0)"],
            borderColor: ["#676C71","#676C71"],
            borderWidth: [0,2],
           
          }
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        //cutoutPercentage: 60,
       //radiusPercentage: 0.5,
        tooltips: {enabled: false},
        hover: {mode: null},
        legend: {
          display: false
        }
      }
    });
    // pointer
    this.chartY = new Chart('canvasY', {
      type: 'pie',
      data: {
        labels: [],
        datasets: [
          { 
            data: this.chartData,
            //backgroundColor: ["#f3f1","#fff"],
            backgroundColor:["rgba(0, 0, 0, 0)","rgba(0, 0, 0,0)"],
            borderColor: ["#fff","#fff"],
            borderWidth: [0,0],
           
          }
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        //cutoutPercentage: 60,
        tooltips: {enabled: false},
        hover: {mode: null},
        legend: {
          display: false
        }
      }
    });
    //value chart
    this.chartF = new Chart('canvasF', {
      type: 'pie',
      data: {
        labels: [],
        datasets: [
          { 
            data: this.chartData,
            backgroundColor: ["rgba(196, 93, 105, 1)","rgba(32, 162, 219, 0)"],
            borderWidth: [0,0],
          }, 
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        cutoutPercentage: 70,
        tooltips: {enabled: false},
        hover: {mode: null},
        legend: {
          display: false
        },
      }
    });
  }

}