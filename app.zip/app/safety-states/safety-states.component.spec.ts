import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SafetyStatesComponent } from './safety-states.component';

describe('SafetyStatesComponent', () => {
  let component: SafetyStatesComponent;
  let fixture: ComponentFixture<SafetyStatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SafetyStatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SafetyStatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
