import { Component, OnDestroy, Injectable, OnInit } from '@angular/core';
import { OperationalDataService } from './services/operational-data.service';
import{SafetyStatesComponent} from './safety-states/safety-states.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {FormGroup, FormControl, Validators} from '@angular/forms';


interface AGV {
  processData: String;
  deviceId: {
    entityId: String;
    serialNumber: String
  }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit {
  assetId: string = '980320';
  dataIn: any;
  newAVG: AGV;
  /************for UI***/
  safeState = {
    stateText:"safe mode",
    iconPath:"./assets/KMP/safe-safe.svg",
    stateCount: 2,
    borderColor: "#1B8642"
  }

  ackState = {
    stateText:"acknowledge",
    iconPath:"./assets/KMP/safe-ack.svg",
    stateCount: 1,
    borderColor: "#9F547D"
  }

  warningState = {
    stateText:"Warning",
    iconPath:"./assets/KMP/safe-warning.svg",
    stateCount: 5,
    borderColor: "#FFCD00"
  }
  errorState = {
    stateText:"E-stop",
    iconPath:"./assets/KMP/safe-estop_sm.svg",
    stateCount: 0,
    borderColor: "#CF2027"
  }
  protectState = {
    stateText:"Protective stop",
    iconPath:"./assets/KMP/safe-protected_sm.svg",
    stateCount: 8,
    borderColor: "#FF5800"
  }
  /************************** */

  /**************************** Chart Part *****************/
  /***********get test data to test liveness of charts */
  chartData= [];
  miForm = new FormGroup({
    data: new FormControl('',Validators.required),
    txt: new FormControl('')
  });

  useData(miForm){
    this.chartData.push(this.data.value);
    this.chartData.push(this.txt.value)
    console.log("got input"+ this.chartData[0]);
    console.log("got input"+ this.chartData[1]);
  }

  get data(){
    return this.miForm.get("data");
  }
  get txt(){
    return this.miForm.get("txt");
  }
  /************************************************************* */
  
  constructor(opDataService:OperationalDataService) {
    opDataService.get(this.assetId).subscribe(avg => {
      this.newAVG = avg;
    });
  }
  ngOnInit() { }
}
