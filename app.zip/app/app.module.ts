import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {OperationalDataService} from './services/operational-data.service'
import { Location,LocationStrategy, PathLocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import {HttpClient} from '@angular/common/http'
import { HttpClientModule } from '@angular/common/http';
import { SafetyStatesComponent } from './safety-states/safety-states.component';
import { ChartMarkerComponent } from './chart-marker/chart-marker.component';
import { GaugesComponent } from './gauges/gauges.component';
import { LegendComponent } from './legend/legend.component';
//import { ChartsModule } from 'ng2-charts';


@NgModule({
  declarations: [
    AppComponent,
    SafetyStatesComponent,
    ChartMarkerComponent,
    GaugesComponent,
    LegendComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule
   // ChartsModule
  ],
  providers: [OperationalDataService,
    HttpClient,
    Location,  {provide: LocationStrategy, useClass: PathLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
