import { Injectable, OnInit } from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http'
import {Observable} from 'rxjs/Observable'

export interface IResponse{

}
const getUrlPrefix = "https://www-dev.kuka-atx.com/api";

@Injectable()
export class DeviceManagementService implements OnInit{
  data:any;
  private getAllUrl:string;
  private siteId = "OlhNIbEUSUW4hJYPyy24Pg";
  private deviceUrl;
  private assetId = "980320";

  constructor(private http: HttpClient) {
    this.getAllUrl = getUrlPrefix  +  '/devices/site/' + this.siteId;
    this.deviceUrl = getUrlPrefix  + '/devices/' +  this.assetId;
  }

  ngOnInit(){
  
  }

  getDeviceProperties(deviceId): Observable<any>{
    //this.assetId = deviceId;
    return this.http.get<any>(this.deviceUrl);
  }

  getAllDevices():Observable<any>{
    return this.http.get<any>(this.getAllUrl);
  }
}
