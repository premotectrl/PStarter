import { Component, OnInit, Input, OnChanges,SimpleChanges, SimpleChange, ElementRef, ViewChild } from '@angular/core';
import {Chart} from 'chart.js';

@Component({
  selector: 'gauge',
  templateUrl: './gauges.component.html',
  styleUrls: ['./gauges.component.css']
})
export class GaugesComponent implements OnInit {
  @ViewChild('cvsP') canvasRefP: ElementRef;
  @ViewChild('cvsP2') canvasRefP2: ElementRef;
  @ViewChild('cvsB') canvasRefB: ElementRef;
  @ViewChild('cvsF') canvasRefF: ElementRef;

  ctxP:any;
  ctxP2:any;
  ctxB:any;
  ctxF:any;
  ctx =[];

  chartP2 = [];
  chartP = [];
  chartB = [];  
  chartF = [];  

 //@Input() data = [20,70];

 // chartData= [];

  /*************** new */
  dataIn:any;
  percentage = "?";

  levelIconPaths =["./assets/KMP/battery-0-10_sm.svg","./assets/KMP/battery-11-25_sm.svg",
  "./assets/KMP/battery-26-50_sm.svg","./assets/KMP/battery-51-75.svg",
  "./assets/KMP/battery-76+_sm.svg","./assets/KMP/battery-unknown_sm.svg"];

  arryIndex = 5;
  
  /******predifined colors *****/
  color = ["#CF2027","#FF5800","#FFCD00","#6EC8A0","#1B8642"];

  @Input() set gaugeConfig(data){this.dataIn = data;}

  get config() {return this.dataIn;}

  constructor() {
    //this.chartData = this.data;
    this.ctx.push(this.ctxP,this.ctxP2,this.ctxB,this.ctxF);
   
  }

  ngOnInit() {
    this.ctx[0] =  this.canvasRefP.nativeElement.getContext('2d');
    this.ctx[1] =   this.canvasRefP2.nativeElement.getContext('2d');
    this.ctx[2] =   this.canvasRefB.nativeElement.getContext('2d');
    this.ctx[3] =   this.canvasRefF.nativeElement.getContext('2d');
    this.makeChart(this.config, this.ctx);
  }

  ngOnChanges(changes: SimpleChanges) {
    const dVal: SimpleChanges = changes.gaugeConfig.currentValue;
    if (dVal != undefined){  
      this.updateChart(this.chartF,dVal,true);
      this.updateChart(this.chartP2,dVal,false);
      this.updateChart(this.chartP,dVal,false);    
    }
  }

  private makeChart(gaugeConfig, ctx) {
    this.chartB = new Chart(ctx[2], {
      type: 'pie',
      data: {
        labels: [],
        datasets: [
          {
            data: [70, 20, 30],
            backgroundColor: ["#E1E2E3", "#D1D3D5", "#A4A7AA"],
            borderWidth: [0.25, 0.25, 0.25]
          }
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        cutoutPercentage: 90,
        legend: {
          display: false
        }
      }
    });
    //value chart
    this.chartF = new Chart(ctx[3], {
      type: 'pie',
      data: {
        labels: [],
        datasets: [
          {
            data: gaugeConfig.level,//this.chartData,
            backgroundColor: ["rgba(196, 93, 105, 0)", "rgba(32, 162, 219, 0)"],
            borderWidth: [0, 0],
          },
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        cutoutPercentage: 70,
        tooltips: { enabled: false },
        hover: { mode: null },
        legend: {
          display: false
        },
      }
    });
    if (gaugeConfig.withPointer == true) {
      //pointer part 1
      this.chartP = new Chart(ctx[0], {
        type: 'pie',
        data: {
          // labels: ["low", "high"],
          datasets: [
            {
              data: gaugeConfig.level,//this.chartData,
              backgroundColor: ["rgba(0, 0, 0, 0)", "rgba(255, 254, 230, 0)"],
              borderColor: ["#676C71", "#676C71"],
              borderWidth: [0, 0.5],

            }
          ]
        },
        options: {
          rotation: 1 * Math.PI,
          circumference: 1 * Math.PI,
          tooltips: { enabled: false },
          hover: { mode: null },
          legend: {
            display: false
          }
        }
      });
      // pointer part 2
      
    }
    this.chartP2 = new Chart(ctx[1], {
      type: 'pie',
      data: {
        labels: [],
        datasets: [
          {
            data: gaugeConfig.level,//this.chartData,
            backgroundColor: ["rgba(0, 0, 0, 0)", "rgba(0, 0, 0,0)"],
            borderColor: ["#fff", "#fff"],
            borderWidth: [0, 0],
          }
        ]
      },
      options: {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        tooltips: { enabled: false },
        hover: { mode: null },
        legend: {
          display: false
        }
      }
    });
  }
  /*********** we have three charts driven together to from  a single chart, so its necessary to update all three */
  private updateChart(updchart, newValue, color) {
    let value = newValue.level[0];
    let percentage = Math.abs(100 - value);
    updchart.data.datasets[0].data[0] = value;
    updchart.data.datasets[0].data[1] = percentage;
    //change colors according to input levels or percentages..
    if (color == true) {
      if (value <= 10) {
        updchart.data.datasets[0].backgroundColor[0] = this.color[0];
        this.arryIndex = 0;
      } else if (value >= 11 && value <= 25) {
        updchart.data.datasets[0].backgroundColor[0] = this.color[1];
        this.arryIndex = 1;
      } else if (value >= 26 && value <= 50) {
        updchart.data.datasets[0].backgroundColor[0] = this.color[2];
        this.arryIndex = 2;
      } else if (value >= 51 && value <= 75) {
        updchart.data.datasets[0].backgroundColor[0] = this.color[3];
        this.arryIndex = 3;
      } else if (value >= 76) {
        updchart.data.datasets[0].backgroundColor[0] = this.color[4];
        this.arryIndex = 4;
      }
    }
    /*********update percentage value displayed on the gauge ****/
    this.percentage = value + '%'
    updchart.update();
  }

}