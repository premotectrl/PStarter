import { Component, OnDestroy, Injectable, OnInit } from '@angular/core';
import { OperationalDataService } from './services/operational-data.service';
import{SafetyStatesComponent} from './safety-states/safety-states.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {FormGroup, FormControl, Validators} from '@angular/forms';

interface AGV {
  processData: String;
  deviceId: {
    entityId: String;
    serialNumber: String
  }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit {
  assetId: string = '980320';
  dataIn: any;
  newAVG: AGV;
  /************for UI***/
  safeState = {
    stateText:"safe mode",
    iconPath:"./assets/KMP/safe-safe.svg",
    stateCount: 2,
    borderColor: "#1B8642"
  }
  ackState = {
    stateText:"acknowledge",
    iconPath:"./assets/KMP/safe-ack.svg",
    stateCount: 1,
    borderColor: "#9F547D"
  }
  warningState = {
    stateText:"Warning",
    iconPath:"./assets/KMP/safe-warning.svg",
    stateCount: 5,
    borderColor: "#FFCD00"
  }
  errorState = {
    stateText:"E-stop",
    iconPath:"./assets/KMP/safe-estop_sm.svg",
    stateCount: 0,
    borderColor: "#CF2027"
  }
  protectState = {
    stateText:"Protective stop",
    iconPath:"./assets/KMP/safe-protected_sm.svg",
    stateCount: 8,
    borderColor: "#FF5800"
  }
  /************************** */

  /**************************** Chart Part *****************/
  /***********get test data to test liveness of charts */
  chartData= [];
  miForm = new FormGroup({
    data: new FormControl('',Validators.required),
    txt: new FormControl('')
  });

  useData(miForm){
    this.chartData.push(this.data.value);
    this.chartData.push(this.txt.value)
  }

  get data(){
    return this.miForm.get("data");
  }
  get txt(){
    return this.miForm.get("txt");
  }
  /****************************this is called in view to provide data to drive gauges ********************************* */
  
  gaugeConfig = {
    avgName: "KMP 8936",
    AVGFleet:"",
    labels:[],
    color: "#f3f1",
    level: [0,100],
    withPointer: true
  }
  /**********just another instance */
  gaugeConfig2 = {
    avgName: "Mobil 3400",
    AVGFleet:"",
    labels:[],
    color: "#f3f1",
    level: [20,80],
    withPointer: false
  }
  /****connection chart data out */
  conChartConfig = {
    labels: ["Connected","Unreliable","Disconnected","Disposed:no data"],
    data:[60, 40, 20, 10],
    type: "connection", //Commandability, Pose reliability
    chartId: "chart2",
    chart: []
  }
  conChartConfig3 = {
    labels: ["Connected","Unreliable","Disconnected","Disposed:no data"],
    data:[0, 40, 20, 90],
    type: "connection", //Commandability, Pose reliability
    chartId: "chart3",
    chart: []
  }

  constructor(opDataService:OperationalDataService) {
    opDataService.get(this.assetId).subscribe(avg => {
      this.newAVG = avg;
    });
  }

  ngOnInit() {
    setInterval(() => {
      this.gaugeConfig.level[0] += 6;
      this.gaugeConfig = Object.assign({},this.gaugeConfig);
      this.conChartConfig.data[0] += 5;
      this.conChartConfig = Object.assign({},this.conChartConfig);
    }, 2000);
   }
}
