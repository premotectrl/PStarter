import { Component, OnInit, OnChanges, Input, SimpleChanges, SimpleChange, ElementRef, ViewChild } from '@angular/core';
import { Chart } from 'chart.js';

@Component({
  selector: 'chartMaker',
  templateUrl: './chart-marker.component.html',
  styleUrls: ['./chart-marker.component.css']
})

export class ChartMarkerComponent implements OnInit, OnChanges {
  @ViewChild('myChart') canvasRef: ElementRef;
  chart = [];
  context:any;
  middleIconPath: String = "./assets/KMP/connect-graph.svg";
  /**************Legend ***/
  legendIcons = ["./assets/KMP/connect-yes_sm.svg",
    "./assets/KMP/connect-disposed_sm.svg",
    "./assets/KMP/connect-no_sm.svg",
    "./assets/KMP/connect-unreliable.svg"];
   
  conChartConfig = {
    labels: [],
    data:[],
    type:String, //Commandability, Pose reliability
    chartId: String,
    chart: [],
    legendIcons: []
  }

  @Input('chartConfig') set chartConfig(data) {
    this.conChartConfig = data;
  }

  get config() { return this.conChartConfig }

  backgroundColor = ["#1B8642", "#6EC8A0", "#CF2027", "#D1D3D5"];
  labels = ["Connected", "Unreliable", "Disconnected", "Disposed:no data"];

  constructor(private elementRef: ElementRef) { }

  ngOnInit() {
    this.context = this.canvasRef.nativeElement.getContext('2d');
    this.makeChart(this.config,this.context);
  }

  ngOnChanges(changes: SimpleChanges) {
    const dVal: SimpleChanges = changes.chartConfig.currentValue;
    this.updateChart(this.chart, dVal);
  }
  
  private makeChart(config, ctx) {
    this.chart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: this.config.labels,
        datasets: [
          {
            data: this.config.data,
            backgroundColor: this.backgroundColor
          }
        ]
      },
      options: {
        cutoutPercentage: 70,
        legend: {
          display: false 
        }
      }
    });
  }

  private updateChart(updChart, newData) {
    updChart.data.datasets[0].data = newData.data;
    updChart.update();
  }

}
